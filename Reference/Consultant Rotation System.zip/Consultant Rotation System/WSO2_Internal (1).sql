-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 14, 2017 at 09:11 PM
-- Server version: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.0.21-1~ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WSO2_Internal`
--

-- --------------------------------------------------------

--
-- Table structure for table `er_feedback`
--

CREATE TABLE `er_feedback` (
  `er_feedback_id` int(11) NOT NULL,
  `er_rotation_id` int(11) NOT NULL,
  `er_feedback` varchar(10000) NOT NULL,
  `er_feedback_rating` varchar(100) NOT NULL,
  `er_feedback_reference` varchar(10000) DEFAULT NULL,
  `er_consultant_email` varchar(100) NOT NULL,
  `er_lead_email` varchar(100) NOT NULL,
  `er_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `er_feedback`
--

INSERT INTO `er_feedback` (`er_feedback_id`, `er_rotation_id`, `er_feedback`, `er_feedback_rating`, `er_feedback_reference`, `er_consultant_email`, `er_lead_email`, `er_updated`) VALUES
(1, 1, 'Somewhat.. OK', 'Needs Improvement', '', 'arunan@wso2.com', 'vidura@wso2.com', '2017-07-18 10:37:19'),
(2, 2, 'Somewhat.. OK', 'Needs Improvement', '', 'arunan@wso2.com', 'vidura@wso2.com', '2017-07-25 15:47:27'),
(3, 3, 'Somewhat.. OK', 'Needs Improvement', '', 'arunan@wso2.com', 'vidura@wso2.com', '2017-07-27 05:30:04'),
(5, 5, 'Somewhat.. OK', 'Needs Improvement', '', 'sajinie@wso2.com', 'vidura@wso2.com', '2017-07-27 06:27:35'),
(6, 8, 'Somewhat.. OK', 'Needs Improvement', '', 'sajinie@wso2.com', 'vidura@wso2.com', '2017-08-01 10:10:41'),
(25, 35, 'Goes early\r\nDoes a good job.', 'Exceptional', 'https://developer.mozilla.org/en-US/docs/Web/API/History_API', 'sajinie@wso2.com', 'vidura@wso2.com', '2017-08-02 09:35:40'),
(55, 65, 'asfadsfdsafs', 'Needs Improvement', 'sdgsdsdgsg', 'arunan@wso2.com', 'vidura@wso2.com', '2017-08-03 11:18:11'),
(56, 66, 'sfafasf', 'Exceptional', 'sfaffa', 'arunan@wso2.com', 'vidura@wso2.com', '2017-08-04 08:26:19'),
(57, 67, 'asfasf', 'Exceptional', 'sfasf', 'arunan@wso2.com', 'sajinie@wso2.com', '2017-08-04 08:28:38'),
(58, 68, 'asfasf', 'Exceptional', 'sfasf', 'arunan@wso2.com', 'sajinie@wso2.com', '2017-08-04 08:30:18'),
(59, 69, 'asfasf', 'Exceptional', 'sfasf', 'arunan@wso2.com', 'sajinie@wso2.com', '2017-08-04 08:43:13'),
(60, 70, 'asfasf', 'Exceptional', 'sfasf', 'arunan@wso2.com', 'sajinie@wso2.com', '2017-08-04 08:43:51'),
(61, 71, 'asfasfasfa', 'Exceptional', 'sfsa', 'kumar@gmail.com', 'vidura@gmail.com', '2017-08-04 13:30:46'),
(62, 72, 'Somewhat.. OK', 'Needs Improvement', '', 'arunan@wso2.com', 'vidura@wso2.com', '2017-08-08 07:10:06'),
(63, 73, 'Somewhat.. OK', 'Needs Improvement', '', 'arunan@wso2.com', 'vidura@wso2.com', '2017-08-08 07:11:23'),
(64, 74, 'Somewhat.. OK', 'Needs Improvement', '', 'arunan@wso2.com', 'vidura@wso2.com', '2017-08-08 07:15:20'),
(65, 75, 'Somewhat.. OK', 'Needs Improvement', 'None', 'arunan@wso2.com', 'vidura@wso2.com', '2017-08-08 09:21:10'),
(66, 77, 'hello', 'Needs Improvement', 'none', 'lakshitha@wso2.cl', 'sajinie@ws.oc', '2017-08-08 09:35:49'),
(67, 78, 'hello', 'Needs Improvement', 'none', 'lakshitha@wso2.cl', 'sajinie@ws.oc', '2017-08-08 09:35:59'),
(68, 79, 'hello', 'Needs Improvement', 'none', 'lakshitha@wso2.cl', 'sajinie@ws.oc', '2017-08-08 09:36:53'),
(69, 80, 'hello', 'Needs Improvement', 'none', 'lakshitha@wso2.cl', 'sajinie@ws.oc', '2017-08-08 09:39:03'),
(70, 81, 'Somewhat.. OK', 'Needs Improvement', 'None', 'arunan@wso2.com', 'vidura@wso2.com', '2017-08-08 10:45:02');

-- --------------------------------------------------------

--
-- Table structure for table `er_feedback_rating`
--

CREATE TABLE `er_feedback_rating` (
  `er_rating` varchar(100) NOT NULL,
  `er_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `er_feedback_rating`
--

INSERT INTO `er_feedback_rating` (`er_rating`, `er_updated`) VALUES
('Exceptional', '2017-07-25 09:34:20'),
('Needs Improvement', '2017-07-17 06:01:31'),
('Successful', '2017-08-03 12:51:43');

-- --------------------------------------------------------

--
-- Table structure for table `er_rotation`
--

CREATE TABLE `er_rotation` (
  `er_rotation_id` int(11) NOT NULL,
  `er_rotation_type` varchar(100) NOT NULL,
  `er_rotation_start_date` varchar(100) NOT NULL,
  `er_rotation_end_date` varchar(100) NOT NULL,
  `er_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `er_rotation`
--

INSERT INTO `er_rotation` (`er_rotation_id`, `er_rotation_type`, `er_rotation_start_date`, `er_rotation_end_date`, `er_updated`) VALUES
(1, 'Cloud Support', '12.02.2017', '15.07.2017', '2017-07-18 10:37:19'),
(2, 'Cloud Support', '12.02.2017', '15.07.2017', '2017-07-25 15:47:27'),
(3, 'Maintenance', '12.02.2017', '15.07.2017', '2017-07-27 05:30:03'),
(5, 'Maintenance', '12.02.2017', '15.07.2017', '2017-07-27 06:27:35'),
(8, 'Maintenance', '12.02.2017', '15.07.2017', '2017-08-01 10:10:41'),
(35, 'Cloud Support', '2017-07-03', '2017-08-15', '2017-08-02 09:35:40'),
(36, 'Cloud Support', '2017-08-10', '2017-08-24', '2017-08-02 11:15:18'),
(65, 'Cloud Support', '08/03/2017', '08/03/2017', '2017-08-03 11:18:11'),
(66, 'Delivery', '05/25/2017', '08/11/2017', '2017-08-04 08:26:19'),
(67, 'Cloud Support', '08/04/2017', '08/04/2017', '2017-08-04 08:28:38'),
(68, 'Cloud Support', '08/04/2017', '08/04/2017', '2017-08-04 08:30:18'),
(69, 'Cloud Support', '08/04/2017', '08/04/2017', '2017-08-04 08:43:13'),
(70, 'Cloud Support', '08/04/2017', '08/04/2017', '2017-08-04 08:43:51'),
(71, 'Cloud Support', '08/04/2017', '08/04/2017', '2017-08-04 13:30:46'),
(72, 'Cloud Support', '12/02/2017', '15/07/2017', '2017-08-08 07:10:04'),
(73, 'Cloud Support', '12/02/2017', '15/07/2017', '2017-08-08 07:11:23'),
(74, 'Cloud Support', '12/02/2017', '15/07/2017', '2017-08-08 07:15:20'),
(75, 'Cloud Support', '02/12/2017', '07/15/2017', '2017-08-08 09:21:10'),
(77, 'Delivery', '06/04/2017', '07/22/2017', '2017-08-08 09:35:48'),
(78, 'Delivery', '06/04/2017', '07/22/2017', '2017-08-08 09:35:59'),
(79, 'Delivery', '06/04/2017', '07/22/2017', '2017-08-08 09:36:53'),
(80, 'Delivery', '06/04/2017', '07/22/2017', '2017-08-08 09:39:03'),
(81, 'Cloud Support', '02/12/2017', '07/15/2017', '2017-08-08 10:45:02');

-- --------------------------------------------------------

--
-- Table structure for table `er_rotation_type`
--

CREATE TABLE `er_rotation_type` (
  `er_rotation_type` varchar(100) NOT NULL,
  `er_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `er_rotation_type`
--

INSERT INTO `er_rotation_type` (`er_rotation_type`, `er_updated`) VALUES
('Cloud Support', '2017-07-17 06:00:23'),
('Delivery', '2017-07-31 16:51:12'),
('Documentation', '2017-08-03 12:29:38'),
('Maintenance', '2017-07-25 09:27:45'),
('Pre-sales', '2017-08-03 12:25:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `er_feedback`
--
ALTER TABLE `er_feedback`
  ADD PRIMARY KEY (`er_feedback_id`),
  ADD UNIQUE KEY `er_feedback_id` (`er_feedback_id`),
  ADD KEY `er_feedback_rating` (`er_feedback_rating`),
  ADD KEY `er_rotation_id` (`er_rotation_id`);

--
-- Indexes for table `er_feedback_rating`
--
ALTER TABLE `er_feedback_rating`
  ADD PRIMARY KEY (`er_rating`),
  ADD UNIQUE KEY `er_rating` (`er_rating`);

--
-- Indexes for table `er_rotation`
--
ALTER TABLE `er_rotation`
  ADD PRIMARY KEY (`er_rotation_id`),
  ADD UNIQUE KEY `er_rotation_id` (`er_rotation_id`),
  ADD KEY `er_rotation_type` (`er_rotation_type`);

--
-- Indexes for table `er_rotation_type`
--
ALTER TABLE `er_rotation_type`
  ADD PRIMARY KEY (`er_rotation_type`),
  ADD UNIQUE KEY `er_rotation_type` (`er_rotation_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `er_feedback`
--
ALTER TABLE `er_feedback`
  MODIFY `er_feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
--
-- AUTO_INCREMENT for table `er_rotation`
--
ALTER TABLE `er_rotation`
  MODIFY `er_rotation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `er_feedback`
--
ALTER TABLE `er_feedback`
  ADD CONSTRAINT `er_feedback_ibfk_1` FOREIGN KEY (`er_feedback_rating`) REFERENCES `er_feedback_rating` (`er_rating`) ON UPDATE CASCADE,
  ADD CONSTRAINT `er_feedback_ibfk_2` FOREIGN KEY (`er_rotation_id`) REFERENCES `er_rotation` (`er_rotation_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `er_rotation`
--
ALTER TABLE `er_rotation`
  ADD CONSTRAINT `er_rotation_ibfk_1` FOREIGN KEY (`er_rotation_type`) REFERENCES `er_rotation_type` (`er_rotation_type`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
