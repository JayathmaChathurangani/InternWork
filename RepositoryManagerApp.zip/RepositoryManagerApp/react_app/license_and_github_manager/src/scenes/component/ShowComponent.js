import React,{Component} from 'react';

class ShowComponent extends Component{
  render(){

    return(
      <h1>Show Component</h1>
    )

  }
}

export default ShowComponent;
